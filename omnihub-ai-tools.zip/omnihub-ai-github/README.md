# OmniHub AI Tools

A fully functional AI-powered tools platform with 9 integrated APIs.

## 🚀 Features

- **🤖 AI Chatbots** - DeepSeek and GPT-OSS for intelligent conversations
- **🎨 Image Generator** - Create stunning images from text prompts
- **📖 Bible Verses** - Daily inspiration and reflection
- **📸 Website Screenshots** - Capture any website instantly
- **🌤️ Weather** - Real-time Philippines weather data
- **💱 Currency Converter** - Live exchange rates
- **📱 QR Code Generator** - Create QR codes from text/URLs
- **🔗 URL Shortener** - Shorten long URLs
- **💬 Beautiful Chat UI** - Modern, responsive interface

## 🛠️ Tech Stack

- React 19
- Tailwind CSS 4
- TypeScript
- Vite
- Wouter (lightweight routing)

## 📦 Installation

### 1. Clone Repository
```bash
git clone https://github.com/YOUR_USERNAME/omnihub-ai-tools.git
cd omnihub-ai-tools
```

### 2. Install Dependencies
```bash
npm install
```

### 3. Run Development Server
```bash
npm run dev
```

Visit `http://localhost:5173`

### 4. Build for Production
```bash
npm run build
```

## 🌐 Deploy on Vercel

1. Push your code to GitHub
2. Go to [Vercel](https://vercel.com)
3. Click "New Project"
4. Select your GitHub repository
5. Click "Deploy"

Your site will be live in seconds!

## 🔌 API Endpoints

All APIs are **free** and **no authentication required**:

| Tool | Endpoint |
|------|----------|
| DeepSeek Chat | `https://jonell.ccprojects.gleeze.com/api/deepseek` |
| GPT-OSS Chat | `https://jonell.ccprojects.gleeze.com/api/gptoss` |
| Image Generator | `https://jonell.ccprojects.gleeze.com/api/poli` |
| Bible Verse | `https://jonell.ccprojects.gleeze.com/api/randomverse` |
| Screenshot | `https://jonell.ccprojects.gleeze.com/api/screenshot` |
| Weather | `https://api.open-meteo.com/v1/forecast` |
| Currency | `https://v6.exchangerate-api.com/v6/latest` |
| QR Code | `https://api.qrserver.com/v1/create-qr-code/` |
| URL Shortener | `https://tinyurl.com/api-create.php` |

## 📝 Usage

1. Select a tool from the sidebar
2. Click on an example or type your own input
3. Click the send button
4. Get instant results!

## 📁 Project Structure

```
omnihub-ai-tools/
├── client/
│   ├── src/
│   │   ├── pages/
│   │   │   ├── Home.tsx
│   │   │   ├── Tools.tsx
│   │   │   └── NotFound.tsx
│   │   ├── App.tsx
│   │   ├── main.tsx
│   │   └── index.css
│   └── index.html
├── tools-config.ts
├── package.json
├── vite.config.ts
├── tsconfig.json
└── README.md
```

## 🎨 Customization

- Edit `tools-config.ts` to add more tools
- Modify `client/src/pages/Tools.tsx` for UI changes
- Update `client/src/index.css` for styling

## 📄 License

MIT

## 👨‍💻 Author

Created with ❤️ for developers

---

**Ready to use? Just clone, install, and deploy!** 🚀
